package com.training.entity;

public class Clinic {
private String city = "Chennai";
private String location = "Shollinganur";
private String pincode = "568344";
private String phoneNumber = "9876543210";
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public String getPincode() {
	return pincode;
}
public void setPincode(String pincode) {
	this.pincode = pincode;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
@Override
public String toString() {
	return "Clinic [city=" + city + ", location=" + location + ", pincode="
			+ pincode + ", phoneNumber=" + phoneNumber + "]";
}


}
