package com.training.entity;

public class Doctor {
	private String name = "Niha";
	private double consultancyFee = 1000.00;
	private int experience = 10;
	Clinic clinic = new Clinic();

	public Clinic getClinic() {
		return clinic;
	}

	public void setClinic(Clinic clinic) {
		this.clinic = clinic;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getConsultancyFee() {
		return consultancyFee;
	}

	public void setConsultancyFee(double consultancyFee) {
		this.consultancyFee = consultancyFee;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

}
