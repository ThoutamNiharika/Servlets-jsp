package com.training.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.training.entity.Doctor;

@WebServlet("/DoctorAddServlet")
public class DoctorAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
int id = Integer.parseInt(request.getParameter("txt1"));		
		String name = request.getParameter("txt2");
		String gender = request.getParameter("txt3");
		String qualification = request.getParameter("txt4");
		int experience = Integer.parseInt(request.getParameter("txt5"));
		double fees = Double.parseDouble(request.getParameter("txt6"));
		Doctor doctor = new Doctor();
		doctor.setId(id);
		doctor.setName(name);
		doctor.setGender(gender);
		doctor.setQualification(qualification);
		doctor.setExperience(experience);
		doctor.setFees(fees);	
				
		HttpSession session = request.getSession(true);
		List<Doctor> doctors = null;
		doctors = (List<Doctor>) session.getAttribute("DOCTORS");
		if (doctors == null) {
			doctors = new ArrayList<Doctor>();
			session.setAttribute("DOCTORS", doctors);
		}
		doctors.add(doctor);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Display4.jsp");
		dispatcher.forward(request, response);
		
		
		
		
	}

}
