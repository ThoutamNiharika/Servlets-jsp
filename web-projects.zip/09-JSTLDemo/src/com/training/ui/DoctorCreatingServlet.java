package com.training.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.entity.Doctor;

@WebServlet("/DoctorCreatingServlet")
public class DoctorCreatingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Doctor doctor1 = new Doctor();
		doctor1.setId(1);
		doctor1.setName("Nikhil");
		doctor1.setGender("male");
		doctor1.setQualification("MBBS");
		doctor1.setExperience(12);
		doctor1.setFees(1500);
		
		Doctor doctor2 = new Doctor();
		doctor2.setId(2);
		doctor2.setName("Niharika");
		doctor2.setGender("Female");
		doctor2.setQualification("MBBS");
		doctor2.setExperience(10);
		doctor2.setFees(1000);		
		
		
		Doctor doctor3 = new Doctor();
		doctor3.setId(3);
		doctor3.setName("Gowtham");
		doctor3.setGender("male");
		doctor3.setQualification("MBBS");
		doctor3.setExperience(13);
		doctor3.setFees(2000);		
		
		
		Doctor doctor4 = new Doctor();
		doctor4.setId(4);
		doctor4.setName("Abhilash");
		doctor4.setGender("male");
		doctor4.setQualification("MBBS");
		doctor4.setExperience(12);
		doctor4.setFees(2000);		
		
		Doctor doctor5 = new Doctor();
		doctor5.setId(5);
		doctor5.setName("Lahari");
		doctor5.setGender("female");
		doctor5.setQualification("MBBS");
		doctor5.setExperience(9);
		doctor5.setFees(1000);		
		
		
		
		
		
		
		List<Doctor> doctors = new ArrayList<Doctor>();
		doctors.add(doctor1);
		doctors.add(doctor2);
		doctors.add(doctor3);
		doctors.add(doctor4);
		doctors.add(doctor5);

		request.setAttribute("DOCTOR", doctors);
		RequestDispatcher dispatcher = request.getRequestDispatcher("Display4.jsp");
		dispatcher.forward(request, response);

	}

}
